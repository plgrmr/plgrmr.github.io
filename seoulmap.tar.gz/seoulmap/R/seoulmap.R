require("rgdal")
require("maptools")
require("ggplot2")
require("plyr")
require("gpclib")
require("ggthemes")

seoulmap <- function(gu = NULL, dong = NULL, fill) {

  if(is.null(dong)) {
    path = paste0(system.file(package = "seoulmap"), "./data")
    seoul = readOGR(dsn=path.expand("../seoulmap/data"), layer="seoul_municipalities")
    seoul@data$id = rownames(seoul@data)
    gpclibPermit()
    seoul.points = fortify(seoul, region="id")
    seoul.df = join(seoul.points, seoul@data, by="id")

    ggplot(seoul.df) +
      aes(long,lat,group=group,fill=SIG_KOR_NM) +
      geom_polygon(data=subset(seoul.df,SIG_KOR_NM==gu), fill=fill) +
      geom_path() +
      coord_equal() +
      theme_tufte()

  } else if(is.null(gu)) {

    seoul = readOGR(dsn=path.expand("../seoulmap/data"), layer="seoul_neighborhoods")
    seoul@data$id = rownames(seoul@data)
    gpclibPermit()
    seoul.points = fortify(seoul, region="id")
    seoul.df = join(seoul.points, seoul@data, by="id")

    ggplot(seoul.df) +
      aes(long,lat,group=group,fill=EMD_KOR_NM) +
      geom_polygon(data=subset(seoul.df,EMD_KOR_NM==dong), fill=fill) +
      geom_path() +
      coord_equal() +
      theme_tufte()

  } else {


  }

}
